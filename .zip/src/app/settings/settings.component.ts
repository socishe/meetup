import { Component, OnInit } from '@angular/core';
import { CatergoryService } from '../catergory.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
category;
  constructor(private categoryService: CatergoryService) { }

  ngOnInit() {
    this.categoryService.getCategories()
    .subscribe(category => {
      console.log(category);
      this.category = category;
    });
  }

}
